class Model(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  fc1 : __torch__.torch.nn.modules.linear.Linear
  relu : __torch__.torch.nn.modules.activation.ReLU
  fc2 : __torch__.torch.nn.modules.linear.___torch_mangle_0.Linear
  def forward(self: __torch__.Modulo_MLP.Model,
    x: Tensor) -> Tensor:
    out = (self.fc1).forward(x, )
    out0 = (self.relu).forward(out, )
    return (self.fc2).forward(out0, )
